package com.navercorp.nid.exception

/**
*
* Created on 2021.10.18
* Updated on 2021.10.18
*
* @author Namhoon Kim. (namhun.kim@navercorp.com)
*         Naver Authentication Platform Development.
*  
* TODO : Write a role for this class.
*/class NidOAuthException {
}